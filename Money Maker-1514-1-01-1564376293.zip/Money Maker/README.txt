READ ME

This mod needs to be installed in your MHW file location Steam/steamapps/common/monster hunter world/nativepc

You can also find your install location through steam. 
	1) Right click game name, select properties
	2) local files tab
	3) browse local files

Just drag nativepc folder into the monster hunter world folder, and the file system should take care of the rest.